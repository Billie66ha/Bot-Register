*Update:*
**```- Pengahapusan cmd
- Improve Live Stats on bot rich presence
- Jika Player 0 Status Bot Akan Menunjukan "Server Online"
Note: Jika ada masalah dm atau tanya disini```**
*Cara Menggunakan:*
**```Via RDP:
- Download node.js
- Ekstrak disini node_modules.zip
- Install node.js
- Buka node js cmd prompt
- Cd lokasi folder bot kalian
- Masukkan bot token di config.json
- Masukkan ip dan port server di bot.js
- Lalu tinggal "node bot.js"```**
